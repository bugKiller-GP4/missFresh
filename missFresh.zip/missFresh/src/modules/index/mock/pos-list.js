var str = require("./pos-list.json")

module.exports = () =>{
	const data = {
		"list.php" : str
	}
	return data
}
