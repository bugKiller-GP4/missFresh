<template lang="html">
	<div>
		<ul>
			<li class="active">
				<i class="iconfont">&#xe607;</i>
				<p>首页</p>
			</li>
			<li>
				<i class="iconfont">&#xe623;</i>
				<p>新鲜事</p>
			</li>
			<li>
				<i class="iconfont">&#xe62c;</i>
				<p>福利</p>
			</li>
			<li>
				<i class="iconfont">&#xe627;</i>
				<p>购物车</p>
			</li>
			<li>
				<i class="iconfont">&#xe647;</i>
				<p>我的</p>
			</li>
		</ul>
	</div>
</template>

<script>
</script>

<style lang="scss">
	@import "../styles/footer.scss";
</style>